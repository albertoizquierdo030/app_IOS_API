//
//  AppDelegate.h
//  UICollectionView_api
//
//  Created by A1-IMAC01 on 12/11/21.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

