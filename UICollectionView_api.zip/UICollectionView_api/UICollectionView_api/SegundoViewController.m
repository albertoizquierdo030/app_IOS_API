//
//  SegundoViewController.m
//  UICollectionView_api
//
//  Created by A1-IMAC01 on 16/11/21.
//

#import "SegundoViewController.h"

@interface SegundoViewController ()

@end

@implementation SegundoViewController

- (void)viewDidLoad {
    [super viewDidLoad];


    
    NSArray * pnameArr = [_pname componentsSeparatedByString: @" "];

    NSString *urlString = [[NSString alloc] initWithFormat:@"https://futuramaapi.herokuapp.com/api/v2/characters?search=%@", pnameArr[0]];
    
    NSError * error;
    NSData * data = [NSData dataWithContentsOfURL:[NSURL URLWithString:urlString]];
    
    NSArray * json = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:&error];
    
    if(json){
        if([json isKindOfClass:[NSArray class]]){
            NSArray * parray = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:&error];
            
            NSDictionary <NSString*, NSString*> *pj = parray[0];
            
            _especie1.text = [[NSString alloc] initWithFormat:@"Especie: %@", [pj objectForKey:@"Species"]];
            _edad1.text = [[NSString  alloc] initWithFormat:@"Edad: %@", [pj objectForKey:@"Age"]];
            _planeta1.text = [[NSString  alloc] initWithFormat:@"Planeta: %@", [pj objectForKey:@"Planet"]];
            _profesion1.text = [[NSString  alloc] initWithFormat:@"Profesión: %@", [pj objectForKey:@"Profession"]];
            _estatus1.text = [[NSString  alloc] initWithFormat:@"Estado: %@", [pj objectForKey:@"Status"]];
            _first1.text = [[NSString  alloc] initWithFormat:@"Apariencia: %@", [pj objectForKey:@"FirstAppearance"]];
            _relatives1.text = [[NSString  alloc] initWithFormat:@"Relativo: %@", [pj objectForKey:@"Relatives"]];
            _voiced1.text = [[NSString  alloc] initWithFormat:@"Voz: %@", [pj objectForKey:@"VoicedBy"]];
            _name1.text = [[NSString  alloc] initWithFormat:@"Nombre: %@", [pj objectForKey:@"Name"]];
    

            
            
            NSString *img = pj[@"PicUrl"];
            NSURL * imgUrl = [NSURL URLWithString:img];
            NSData * datas = [[NSData alloc] initWithContentsOfURL:imgUrl];
            [_imagen2 setImage:[UIImage imageWithData:datas]];
            
    
        }
    }
    
}



@end
