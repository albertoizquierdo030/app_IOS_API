//
//  ViewController.h
//  UICollectionView_api
//
//  Created by A1-IMAC01 on 12/11/21.
//

#import <UIKit/UIKit.h>
#import "CollectionViewCell.h"
#import "SegundoViewController.h"

NSArray * personajes;
NSArray * bender;
NSArray * arrayInfo;


@interface ViewController : UIViewController <UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout>



@property (strong, nonatomic) IBOutlet UICollectionView *miCollectionView;



@end

