//
//  SegundoViewController.h
//  UICollectionView_api
//
//  Created by A1-IMAC01 on 16/11/21.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface SegundoViewController : UIViewController

@property NSString * pname;

@property NSString * espe;
@property NSString * eda;
@property NSString * plane;
@property NSString * prof;
@property NSString * esta;
@property NSString * fi;
@property NSString * rela;
@property NSString * voi;
@property NSString * nam;

@property NSString * img;

@property (strong, nonatomic) IBOutlet UILabel *especie1;
@property (strong, nonatomic) IBOutlet UILabel *edad1;
@property (strong, nonatomic) IBOutlet UILabel *planeta1;
@property (strong, nonatomic) IBOutlet UILabel *profesion1;
@property (strong, nonatomic) IBOutlet UILabel *estatus1;
@property (strong, nonatomic) IBOutlet UILabel *first1;
@property (strong, nonatomic) IBOutlet UILabel *relatives1;
@property (strong, nonatomic) IBOutlet UILabel *voiced1;
@property (strong, nonatomic) IBOutlet UILabel *name1;


@property (strong, nonatomic) IBOutlet UIImageView *imagen2;







@end

NS_ASSUME_NONNULL_END
