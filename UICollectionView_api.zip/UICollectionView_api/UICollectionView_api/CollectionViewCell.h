//
//  CollectionViewCell.h
//  UICollectionView_api
//
//  Created by A1-IMAC01 on 12/11/21.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface CollectionViewCell : UICollectionViewCell

@property (strong, nonatomic) IBOutlet UIImageView *imagen;

@property (strong, nonatomic) IBOutlet UILabel *titulo;




@end

NS_ASSUME_NONNULL_END
