//
//  ViewController.m
//  UICollectionView_api
//
//  Created by A1-IMAC01 on 12/11/21.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self lanzarPeticion];
    
}

-(void)lanzarPeticion{
    personajes = [[NSArray alloc] init];
    
    NSString *urlString = @"https://futuramaapi.herokuapp.com/api/quotes";
    
    NSError * error;
    NSData * data = [NSData dataWithContentsOfURL:[NSURL URLWithString:urlString]];
    
    NSString * json = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:&error];
    if(json){
        if([json isKindOfClass:[NSArray class]]){
            personajes = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:&error];
        }
    }
}


- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    return 1;
}


- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return [personajes count];
}


- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    CGFloat ancho = (CGRectGetWidth(_miCollectionView.frame) / 2) - 5;
    
    return CGSizeMake(ancho, ancho*2);
}




-(__kindof UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    CollectionViewCell * cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"proto1" forIndexPath:indexPath];
    
    NSString * nombre = [personajes[indexPath.item] valueForKey:@"character"];
    
    
    NSString * imageString = [personajes[indexPath.item]valueForKey:@"image"];
    
    NSURL * imageUrl = [NSURL URLWithString:imageString];
    
    NSData * imageData = [[NSData alloc] initWithContentsOfURL:imageUrl];
    
    [cell.titulo setText:nombre];
    [cell.imagen setImage:[UIImage imageWithData:imageData]];
    
    return cell;
    
}




- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    NSLog(@"Se ha pulsado la celda %ld", (long)indexPath.item);
    
    NSString * nombre = [personajes[indexPath.item] valueForKey:@"character"];
    
    NSString * sinEspacios = [nombre stringByReplacingOccurrencesOfString:@" " withString:@"-"];
    
    NSString *urlStringBender = @"https://futuramaapi.herokuapp.com/api/characters/";
    
    NSString * fraseQ = [[NSString alloc] initWithFormat:@"%@%@/1", urlStringBender, sinEspacios];
    
    NSError * error;
    NSData * data = [NSData dataWithContentsOfURL:[NSURL URLWithString:fraseQ]];
    
    NSString * json = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:&error];
    if(json){
        if([json isKindOfClass:[NSArray class]]){
            bender = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:&error];
        }
    }
    
    NSString * finally;
    
    if(bender.count == 0){
        finally = @"Sin frases";
    }else{
        finally = [bender[0] valueForKey:@"quote"];
    }
    

    
    UIAlertController * alert = [UIAlertController alertControllerWithTitle:nombre message:finally preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction * accionInfo = [UIAlertAction actionWithTitle:@"Ver info" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action){
        
        //peticion de la info
        NSString * urlInfo = @"https://futuramaapi.herokuapp.com/api/v2/characters?search=";
        
        NSString * conEspacios = [nombre stringByReplacingOccurrencesOfString:@" " withString:@"%20"];
        
        NSString * urlOk = [[NSString alloc] initWithFormat:@"%@%@",urlInfo,conEspacios];
        NSError * error2;
        NSData * data2 = [NSData dataWithContentsOfURL:[NSURL URLWithString:urlOk]];
        
        //tenemos la url del personaje
        NSLog(@"urlok: %@", urlOk);
        
        NSString * json2 = [NSJSONSerialization JSONObjectWithData:data2 options:kNilOptions error:&error2];
        if(json2){
            if([json2 isKindOfClass:[NSArray class]]){
                arrayInfo = [NSJSONSerialization JSONObjectWithData:data2 options:kNilOptions error:&error2];
            }
        }
               
        //pasar a la segunda pantalla
        UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        
        SegundoViewController * dvc = [mainStoryboard instantiateViewControllerWithIdentifier:@"segundoVC"];
        
        dvc.pname = [personajes[indexPath.item] valueForKey:@"character"];
        
        [self presentViewController:dvc animated:YES completion:nil];
        
        
    }];
    
    UIAlertAction * accionCancelar = [UIAlertAction actionWithTitle:@"Cancelar" style:UIAlertActionStyleCancel handler:nil];
 
    
    [alert addAction:accionCancelar];
    [alert addAction:accionInfo];
    [self presentViewController:alert animated:YES completion:nil];
}


@end
