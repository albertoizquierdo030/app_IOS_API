//
//  SceneDelegate.h
//  UICollectionView_api
//
//  Created by A1-IMAC01 on 12/11/21.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

